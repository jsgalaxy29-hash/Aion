﻿namespace Aion.DataEngine.Entities
{
    public class SAction : BaseEntity
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
       
        public string ActionCode { get; set; } = string.Empty;

    }
}